package com.example.flutter_application_insta

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
